package com.example.airlineroutes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineRoutesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineRoutesApplication.class, args);
	}

}
