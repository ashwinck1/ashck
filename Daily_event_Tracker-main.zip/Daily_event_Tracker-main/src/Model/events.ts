export class events{
id:number|undefined;
    taskName:string|undefined;
    deadline:string|undefined;
    status:string|undefined;
    comment:string|undefined
}