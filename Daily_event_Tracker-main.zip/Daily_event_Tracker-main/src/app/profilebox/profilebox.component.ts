import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-profilebox',
  templateUrl: './profilebox.component.html',
  styleUrls: ['./profilebox.component.css']
})
export class ProfileboxComponent {
  @Input() userId: string | undefined;
  @Input() username: string | undefined;
  showProfile: boolean = false;

  toggleProfile() {
    this.showProfile = !this.showProfile;
  }
}










