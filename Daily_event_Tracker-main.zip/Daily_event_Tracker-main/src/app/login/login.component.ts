import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  


  selectedRole!: string;
  constructor(private router: Router) {}

  redirectToDashboard() {
    if (this.selectedRole === 'user') {
      this.router.navigate(['/userdashboard']); // Navigate to the userdashboard route
    }
    if (this.selectedRole === 'admin') {
      this.router.navigate(['/admindashboard']);
    }
  }

}



// @Component({
//   selector: 'app-logo',
//   template: `
//     <div class="logo">
//       <img src="path/to/logo.png" alt="Logo" />
//       <h1>My Daily Events</h1>
//     </div>
//   `,
//   styleUrls: ['./logo.component.css']
// })

