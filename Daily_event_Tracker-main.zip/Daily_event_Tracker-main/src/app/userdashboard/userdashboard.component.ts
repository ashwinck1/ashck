import { Component,Input } from '@angular/core';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent {
  @Input() userId: string | undefined;
  @Input() username: string | undefined;
  @Input() notificationCount: number = 0;
  // @Input() notificationCount: number | undefined;
  incrementNotificationCount() {
    this.notificationCount++;
  }
  showProfile: boolean = false;

  toggleProfile() {
    this.showProfile = !this.showProfile;
  }

}







