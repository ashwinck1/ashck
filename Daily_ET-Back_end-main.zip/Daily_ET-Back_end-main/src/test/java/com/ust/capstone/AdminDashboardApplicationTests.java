package com.ust.capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
