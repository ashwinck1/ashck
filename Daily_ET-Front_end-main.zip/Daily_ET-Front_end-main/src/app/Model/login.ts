export class Login {

    username: string;
    password: string;
    type: string;
  name: any;

    constructor() {
        this.password = '';
        this.username = '';
        this.type = '';
    }

}