export class user{
    userId :number|undefined;
	name:string|undefined;
	status:string|undefined;
	comment:string|undefined;
}