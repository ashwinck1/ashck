export class Signup
{    
    username: string;
    name: string; 
    password: string;
    email: string;
    conpassword: string;
    type: string;

    constructor() {
        this.username = '';
        this.name = '';
        this.password = '';
        this.email = '';
        this.conpassword= '';
        this.type= '';
      }

}